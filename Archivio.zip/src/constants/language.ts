export const languages = ["pt", "en"];
