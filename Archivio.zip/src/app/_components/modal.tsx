"use client";

import { Check, X } from "lucide-react";
import { ReactNode } from "react";
import { useTranslations } from "next-intl";

interface GalleryItem {
  id: string;
  key: string; // chave de tradução
  icon?: ReactNode;
  namespace?: "galLery" | "mentorias"; // namespace das traduções
}

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  item?: GalleryItem;
}

const Modal = ({ isOpen, onClose, item }: ModalProps) => {
  const namespace = item?.namespace || "galLery";
  const t = useTranslations(namespace);

  if (!isOpen || !item) return null;

  // pega lista direto do JSON de traduções
  const listItems = t.raw(`items.${item.key}.listItems`) as string[] | undefined;

  return (
    <div className="fixed inset-0 bg-black/70 flex items-center justify-center z-50 p-4">
      <div className="bg-[#1e1e1e] text-white rounded-2xl max-w-2xl w-full p-8 relative shadow-xl shadow-[#E32320]/30">
        {/* Botão Fechar */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-gray-400 hover:text-white"
        >
          <X size={24} />
        </button>

        {/* Cabeçalho */}
        <div className="flex items-center gap-4 mb-6">
          {item.icon}
          <h2 className="text-2xl font-bold text-[#E32320]">
            {t(`items.${item.key}.title`)}
          </h2>
        </div>

        {/* Descrição */}
        <p className="text-gray-300 mb-6">
          {t(`items.${item.key}.description`)}
        </p>

        {/* Lista de itens */}
        {Array.isArray(listItems) && listItems.length > 0 && (
          <ul className="space-y-3 text-sm text-gray-400">
            {listItems.map((listItem, index) => (
              <li key={index} className="flex items-center gap-3">
                <Check className="w-5 h-5 text-[#E32320]" />
                <span>{listItem}</span>
              </li>
            ))}
          </ul>
        )}
      </div>
    </div>
  );
};

export default Modal;
