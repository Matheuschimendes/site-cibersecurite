import GalleryTreinamento from "../_components/galleryTreinamento";

export const Treinamento = () => {
  return (
    <div>
      <GalleryTreinamento />
    </div>
  );
}
